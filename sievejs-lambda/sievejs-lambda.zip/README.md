This is an experiment to see if I can get sieve running on lambda.
